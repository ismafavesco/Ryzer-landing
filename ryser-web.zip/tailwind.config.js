/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: '#fafaf7',
        'bg-alt': '#f2f0e8',
        ink: '#1a2a20',
        'ink-mid': '#4a5a50',
        'ink-dim': '#7a8a80',
        line: '#d9d5c7',
        accent: '#1a4d2e',
        'accent-light': '#2d7a47',
        gold: '#c8a560',
      },
      fontFamily: {
        serif: ['Fraunces', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
