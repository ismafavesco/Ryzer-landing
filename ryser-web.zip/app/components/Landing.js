"use client"

import { useRef, useEffect } from "react"
import Image from "next/image"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useGSAP } from "@gsap/react"

gsap.registerPlugin(ScrollTrigger, useGSAP)

const services = [
  { n: "01", title: "Transporte de residuos", desc: "Traslado especializado con bitácora, rastreo y documentación normativa completa." },
  { n: "02", title: "Disposición y manejo de residuos", desc: "Reciclaje de materiales, disposición de residuos no peligrosos y destrucciones certificadas." },
  { n: "03", title: "Medición de huella de carbono", desc: "Cuantificación bajo estándares internacionales GHG Protocol e ISO 14064." },
  { n: "04", title: "Servicios de gestoría", desc: "Trámites, permisos y asesoría en cumplimiento normativo federal y estatal." },
  { n: "05", title: "Mejora de procesos", desc: "Implementación de soluciones a medida para cualquier requerimiento operativo o técnico." },
  { n: "06", title: "Servicios transversales", desc: "Soluciones que integran múltiples áreas bajo un mismo estándar operativo y ambiental." },
]

const products = [
  {
    tag: "Madera",
    dims: "40 × 48 in",
    title: "Tarima de barrote",
    desc: "Fabricada con barrotes de madera con resaques que permiten el acceso de montacargas por los cuatro lados. Ideal para operaciones de alta rotación.",
    img: "/tarimas.jpg",
  },
  {
    tag: "Madera",
    dims: "40 × 48 in",
    title: "Tarima de cubo",
    desc: "Construida con bloques sólidos de madera que separan las cubiertas superior e inferior. Mayor resistencia y durabilidad para exportación.",
    img: null,
  },
  {
    tag: "Plástico",
    dims: "LDPE / Variado",
    title: "Rejas y plásticos reciclados",
    desc: "Rejas industriales de distintos tipos y plásticos LDPE recuperados, clasificados y disponibles para reutilización o reprocesamiento.",
    img: null,
  },
]

function ArrowRight({ className = "", size = 18 }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M5 12h14M13 5l7 7-7 7" />
    </svg>
  )
}

function ArrowUpRight({ className = "", size = 20 }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M7 17L17 7M7 7h10v10" />
    </svg>
  )
}

function ChevronDown({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 5v14M5 12l7 7 7-7" />
    </svg>
  )
}

function Eyebrow({ children }) {
  return (
    <div className="text-[0.68rem] uppercase tracking-[0.2em] text-accent font-bold mb-4 inline-flex items-center gap-3">
      <span className="w-8 h-[2px] bg-accent-light" />
      <span>{children}</span>
    </div>
  )
}

function SectionTitle({ children }) {
  return (
    <h2 className="font-serif text-[clamp(2rem,8.5vw,3.2rem)] font-light leading-[1.08] tracking-tight mb-4 text-ink">
      {children}
    </h2>
  )
}

export default function Landing() {
  const container = useRef(null)

  useGSAP(() => {
    // HERO
    const heroTl = gsap.timeline({ defaults: { ease: "power3.out" } })
    heroTl
      .from(".hero-meta-item", { y: -8, autoAlpha: 0, duration: 0.5, stagger: 0.08 })
      .from(".hero-logo-big", { scale: 0.7, autoAlpha: 0, duration: 0.7, ease: "back.out(1.4)" }, "-=0.2")
      .from(".hero-eyebrow", { y: 10, autoAlpha: 0, duration: 0.5 }, "-=0.3")
      .from(".hero-word", { yPercent: 100, duration: 0.85, stagger: 0.07, ease: "power4.out" }, "-=0.2")
      .from(".hero-sub", { y: 14, autoAlpha: 0, duration: 0.6 }, "-=0.4")
      .from(".hero-photo", { autoAlpha: 0, y: 20, duration: 0.7 }, "-=0.3")
      .from(".hero-btn", { y: 14, autoAlpha: 0, duration: 0.5, stagger: 0.1 }, "-=0.3")
      .from(".hero-trust", { autoAlpha: 0, duration: 0.5 }, "-=0.2")

    // SCROLL-TRIGGERED (all with immediateRender: false)
    const stOpts = { immediateRender: false }

    gsap.from(".div-anim", {
      scrollTrigger: { trigger: ".divisions-section", start: "top 88%" },
      y: 20, autoAlpha: 0, duration: 0.7, stagger: 0.1, ease: "power3.out", ...stOpts,
    })

    gsap.from(".product-card", {
      scrollTrigger: { trigger: ".product-list", start: "top 88%" },
      y: 24, autoAlpha: 0, duration: 0.7, stagger: 0.12, ease: "power3.out", ...stOpts,
    })

    gsap.from(".service-item", {
      scrollTrigger: { trigger: ".service-list", start: "top 88%" },
      y: 18, autoAlpha: 0, duration: 0.6, stagger: 0.08, ease: "power3.out", ...stOpts,
    })

    gsap.from(".about-anim", {
      scrollTrigger: { trigger: ".about-body", start: "top 88%" },
      y: 18, autoAlpha: 0, duration: 0.7, stagger: 0.12, ease: "power3.out", ...stOpts,
    })

    gsap.from(".contact-anim", {
      scrollTrigger: { trigger: ".contact-cards", start: "top 90%" },
      y: 18, autoAlpha: 0, duration: 0.6, stagger: 0.08, ease: "power3.out", ...stOpts,
    })

    gsap.from(".form-anim", {
      scrollTrigger: { trigger: ".form-anim", start: "top 92%" },
      y: 24, autoAlpha: 0, duration: 0.7, ease: "power3.out", ...stOpts,
    })

    // Refresh on load
    window.addEventListener("load", () => ScrollTrigger.refresh())
  }, { scope: container })

  return (
    <div ref={container} className="min-h-screen bg-bg text-ink overflow-x-hidden">
      {/* NAV */}
      <nav className="sticky top-0 z-50 bg-bg/95 backdrop-blur-md border-b border-line">
        <div className="flex justify-between items-center px-6 py-3.5">
          <div className="flex items-center gap-2.5">
            <Image src="/logo.jpg" alt="RYSER" width={34} height={34} className="rounded-full" />
            <span className="font-serif text-xl font-semibold tracking-tight text-ink">RYSER</span>
          </div>
          <a href="#contacto" className="text-[0.78rem] font-medium text-ink px-4 py-2 border border-ink rounded-full hover:bg-ink hover:text-white transition-all active:scale-95">
            Contáctanos
          </a>
        </div>
      </nav>

      {/* HERO */}
      <section className="bg-bg px-6 pt-10 pb-14 border-b border-line">
        <div className="flex justify-between items-start mb-10 pb-5 border-b border-line gap-2">
          <div className="hero-meta-item flex-1">
            <div className="text-[0.6rem] uppercase tracking-[0.14em] text-ink-dim font-semibold">Desde</div>
            <div className="text-ink font-bold text-[0.72rem] mt-1 tracking-wide">2013</div>
          </div>
          <div className="hero-meta-item flex-1 text-right">
            <div className="text-[0.6rem] uppercase tracking-[0.14em] text-ink-dim font-semibold">Base</div>
            <div className="text-ink font-bold text-[0.72rem] mt-1 tracking-wide">Chihuahua, MX</div>
          </div>
        </div>

        <div className="hero-logo-big flex justify-center mb-8">
          <Image src="/logo.jpg" alt="RYSER Logo" width={110} height={110} className="rounded-full" />
        </div>

        <div className="hero-eyebrow text-[0.68rem] uppercase tracking-[0.2em] text-accent font-bold mb-6 inline-flex items-center gap-3">
          <span className="w-8 h-[2px] bg-accent-light" />
          <span>Reciclados y Servicios</span>
        </div>

        <h1 className="font-serif text-[clamp(2.6rem,11vw,4.5rem)] font-light leading-[1.02] tracking-tight mb-7 text-ink">
          <span className="block overflow-hidden py-[0.08em]"><span className="hero-word inline-block text-ink">Gestión</span></span>
          <span className="block overflow-hidden py-[0.08em]"><span className="hero-word inline-block text-ink">que </span><em className="hero-word inline-block italic text-accent font-light">transforma</em></span>
          <span className="block overflow-hidden py-[0.08em]"><span className="hero-word inline-block text-ink">residuos</span></span>
          <span className="block overflow-hidden py-[0.08em]"><span className="hero-word inline-block text-ink">en valor.</span></span>
        </h1>

        <p className="hero-sub text-[1.02rem] text-ink-mid max-w-[38ch] mb-8 leading-relaxed">
          Diseñamos soluciones integrales en reciclaje y servicios industriales que impulsan la eficiencia, el cumplimiento normativo y la sostenibilidad de nuestros clientes.
        </p>

        {/* Hero photo */}
        <div className="hero-photo -mx-6 mb-8 h-56 overflow-hidden border-y border-line relative">
          <Image src="/tarimas.jpg" alt="Patio de tarimas RYSER" fill className="object-cover object-center" />
          <div className="absolute bottom-3 left-6 bg-bg/95 backdrop-blur px-3 py-1.5 rounded-full text-[0.6rem] uppercase tracking-[0.14em] font-bold text-ink">
            ● Patio de operaciones
          </div>
        </div>

        <div className="flex flex-col gap-3 mb-8">
          <a href="#contacto" className="hero-btn flex justify-between items-center gap-4 bg-accent text-white px-6 py-4 rounded-full text-[0.88rem] font-medium active:scale-[0.98] transition-all">
            <span>Solicitar cotización</span>
            <ArrowRight size={18} />
          </a>
          <a href="#productos" className="hero-btn flex justify-between items-center gap-4 border border-ink text-ink px-6 py-4 rounded-full text-[0.88rem] font-medium active:bg-ink active:text-white transition-all">
            <span>Ver productos y servicios</span>
            <ChevronDown size={18} />
          </a>
        </div>

        <div className="hero-trust flex items-center gap-3 pt-6 border-t border-line">
          <div className="flex gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <span className="w-1.5 h-1.5 rounded-full bg-accent opacity-65" />
            <span className="w-1.5 h-1.5 rounded-full bg-accent opacity-35" />
          </div>
          <p className="text-[0.78rem] text-ink-mid leading-snug">
            <strong className="text-ink font-semibold">Gestión integral</strong> de residuos industriales en Chihuahua.
          </p>
        </div>
      </section>

      {/* DIVISIONS */}
      <section className="divisions-section bg-bg-alt px-6 py-12 border-b border-line">
        <div className="div-anim text-center mb-2">
          <div className="text-[0.65rem] uppercase tracking-[0.2em] text-ink-dim font-bold">Dos líneas de negocio</div>
        </div>
        <div className="div-anim text-center mb-8">
          <div className="font-serif text-[1.45rem] font-normal italic text-ink leading-snug">Una sola promesa de valor.</div>
        </div>
        <div className="grid gap-3">
          {[
            { n: "I.", title: "Venta de material reciclado", desc: "Tarimas de madera, rejas industriales y plásticos LDPE recuperados, listos para reutilización." },
            { n: "II.", title: "Servicios industriales personalizados", desc: "Transporte, disposición, gestoría, huella de carbono y mejora de procesos a la medida." },
          ].map((d, i) => (
            <a key={i} href={i === 0 ? "#productos" : "#servicios"} className="div-anim flex gap-4 items-start bg-bg border border-line rounded-2xl p-5 active:border-accent transition-all">
              <span className="font-serif italic text-accent font-semibold min-w-[1.6rem] pt-0.5">{d.n}</span>
              <div>
                <h3 className="font-serif text-[1.15rem] font-semibold text-ink mb-1.5 leading-snug">{d.title}</h3>
                <p className="text-[0.86rem] text-ink-mid leading-relaxed">{d.desc}</p>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* PRODUCTS */}
      <section id="productos" className="bg-bg px-6 py-12 border-b border-line">
        <Eyebrow>Línea 01 — Material reciclado</Eyebrow>
        <SectionTitle>
          Tarimas y <em className="italic text-accent font-light">plásticos</em> listos para reutilizar.
        </SectionTitle>
        <p className="text-ink-mid text-[0.96rem] max-w-[44ch] mb-8 leading-relaxed">
          Material recuperado, inspeccionado y listo para integrarse a tu cadena logística o línea de producción.
        </p>

        <div className="product-list flex flex-col gap-4">
          {products.map((p, i) => (
            <div key={i} className="product-card bg-bg-alt border border-line rounded-2xl overflow-hidden">
              {p.img && (
                <div className="relative h-48 border-b border-line">
                  <Image src={p.img} alt={p.title} fill className="object-cover" />
                </div>
              )}
              <div className="p-5">
                <div className="flex justify-between items-center mb-4 pb-4 border-b border-line">
                  <span className="text-[0.58rem] uppercase tracking-[0.14em] text-accent font-bold bg-bg px-3 py-1.5 rounded-full border border-accent">{p.tag}</span>
                  <span className="font-mono text-[0.68rem] text-ink-dim font-semibold">{p.dims}</span>
                </div>
                <h3 className="font-serif text-[1.3rem] font-semibold text-ink mb-2 leading-snug">{p.title}</h3>
                <p className="text-[0.88rem] text-ink-mid leading-relaxed">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section id="servicios" className="bg-bg px-6 py-12 border-b border-line">
        <Eyebrow>Línea 02 — Servicios industriales</Eyebrow>
        <SectionTitle>
          Soluciones <em className="italic text-accent font-light">personalizadas</em> para tu operación.
        </SectionTitle>
        <p className="text-ink-mid text-[0.96rem] max-w-[44ch] mb-8 leading-relaxed">
          Seis áreas de especialidad diseñadas para cubrir cada necesidad de gestión ambiental y operativa de tu empresa.
        </p>

        <div className="service-list">
          {services.map((s, i) => (
            <a key={i} href="#contacto" className={`service-item block py-5 border-t border-line active:pl-2 transition-all ${i === services.length - 1 ? "border-b" : ""}`}>
              <div className="flex justify-between items-start gap-3 mb-2">
                <span className="font-mono text-[0.68rem] text-accent tracking-wide font-bold pt-1.5 min-w-[2.4rem]">{s.n} —</span>
                <h3 className="font-serif text-[1.22rem] font-semibold leading-snug text-ink flex-1">{s.title}</h3>
                <ArrowUpRight className="text-ink-dim mt-1.5 shrink-0" size={20} />
              </div>
              <p className="text-[0.88rem] text-ink-mid pl-[3.25rem] leading-relaxed">{s.desc}</p>
            </a>
          ))}
        </div>
      </section>

      {/* ABOUT */}
      <section className="bg-accent text-white px-6 py-14 border-b border-line">
        <div className="text-[0.68rem] uppercase tracking-[0.2em] text-gold font-bold mb-4 inline-flex items-center gap-3">
          <span className="w-8 h-[2px] bg-gold" />
          <span>Más sobre nosotros</span>
        </div>
        <h2 className="font-serif text-[clamp(2rem,8.5vw,3.2rem)] font-light leading-[1.08] tracking-tight mb-4 text-white">
          Gestión que <em className="italic text-gold font-light">transforma.</em>
        </h2>
        <div className="about-body mt-7">
          <p className="about-anim font-serif text-[1.18rem] italic text-white leading-relaxed mb-4 max-w-[44ch]">
            &ldquo;Cada contacto activa un proceso ágil de análisis y seguimiento para ofrecer soluciones a la medida, seguras y alineadas con los más altos estándares operativos y ambientales.&rdquo;
          </p>
          <p className="about-anim text-[0.96rem] text-white/90 leading-relaxed mb-4 max-w-[44ch]">
            En RYSER convertimos la gestión de residuos en valor operativo y ambiental. Diseñamos soluciones integrales en reciclaje y servicios industriales que impulsan la eficiencia, el cumplimiento normativo y la sostenibilidad de nuestros clientes.
          </p>
          <div className="about-anim grid grid-cols-2 gap-4 pt-6 mt-6 border-t border-white/20">
            <div>
              <div className="text-[0.62rem] uppercase tracking-[0.15em] text-gold font-bold mb-1.5">Base</div>
              <div className="font-serif text-[0.98rem] text-white font-medium">Chihuahua, México</div>
            </div>
            <div>
              <div className="text-[0.62rem] uppercase tracking-[0.15em] text-gold font-bold mb-1.5">Fundación</div>
              <div className="font-serif text-[0.98rem] text-white font-medium">Año 2013</div>
            </div>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contacto" className="bg-bg-alt px-6 py-12 border-b border-line">
        <Eyebrow>Contáctanos</Eyebrow>
        <SectionTitle>
          <em className="italic text-accent font-light">¿Quieres</em> que trabajemos juntos?
        </SectionTitle>
        <p className="text-ink-mid text-[0.96rem] max-w-[44ch] mb-6 leading-relaxed">
          Ingresa tus datos y nos pondremos en contacto contigo en breve. Esperamos tener noticias tuyas pronto.
        </p>

        <div className="contact-cards flex flex-col gap-3 mb-6">
          <a href="https://wa.me/5216147581449" className="contact-anim flex justify-between items-center gap-3 bg-accent text-white border border-accent rounded-2xl px-5 py-4 active:scale-[0.98] transition-all">
            <div>
              <div className="text-[0.58rem] uppercase tracking-[0.15em] text-gold font-bold mb-1">WhatsApp</div>
              <div className="font-serif text-[1rem] font-semibold">Escribir ahora</div>
            </div>
            <ArrowUpRight className="text-gold" size={22} />
          </a>
          <a href="tel:+526147581449" className="contact-anim flex justify-between items-center gap-3 bg-bg border border-line rounded-2xl px-5 py-4 active:border-accent transition-all">
            <div>
              <div className="text-[0.58rem] uppercase tracking-[0.15em] text-ink-dim font-bold mb-1">Teléfono</div>
              <div className="font-serif text-[1rem] font-semibold text-ink">(614) 758 14 49</div>
            </div>
            <ArrowUpRight className="text-ink-dim" size={20} />
          </a>
          <a href="mailto:jpinon@reciladosyservicios.com" className="contact-anim flex justify-between items-center gap-3 bg-bg border border-line rounded-2xl px-5 py-4 active:border-accent transition-all">
            <div className="min-w-0">
              <div className="text-[0.58rem] uppercase tracking-[0.15em] text-ink-dim font-bold mb-1">Correo</div>
              <div className="font-serif text-[0.86rem] font-semibold text-ink break-all">jpinon@reciladosyservicios.com</div>
            </div>
            <ArrowUpRight className="text-ink-dim shrink-0" size={20} />
          </a>
          <div className="contact-anim bg-bg border border-line rounded-2xl px-5 py-4">
            <div className="text-[0.58rem] uppercase tracking-[0.15em] text-ink-dim font-bold mb-1">Ubicación</div>
            <div className="font-serif text-[0.9rem] font-medium text-ink leading-snug">
              Calle Sierra del Morrión #5306<br />
              Col. Primero de Mayo, C.P. 31074<br />
              Chihuahua, Chihuahua
            </div>
          </div>
        </div>

        {/* FORM */}
        <div className="form-anim bg-bg border border-line rounded-2xl p-6 relative">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-bg-alt px-3 font-serif italic text-[0.85rem] text-ink-dim">o</div>
          <h3 className="font-serif text-[1.3rem] font-semibold text-ink mb-2">Envíanos un mensaje</h3>
          <p className="text-[0.86rem] text-ink-mid mb-6 leading-relaxed">Completa el formulario y te responderemos en menos de 24 horas hábiles.</p>

          <form onSubmit={(e) => { e.preventDefault(); alert("Demo: en producción este formulario envía el mensaje al correo de RYSER.") }}>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-[0.64rem] uppercase tracking-[0.12em] text-ink-mid font-bold mb-2">Nombre <span className="text-gold">*</span></label>
                <input type="text" required className="w-full bg-bg-alt border border-line rounded-xl px-4 py-3 text-[0.92rem] text-ink focus:border-accent focus:bg-bg outline-none transition-all" />
              </div>
              <div>
                <label className="block text-[0.64rem] uppercase tracking-[0.12em] text-ink-mid font-bold mb-2">Apellido <span className="text-gold">*</span></label>
                <input type="text" required className="w-full bg-bg-alt border border-line rounded-xl px-4 py-3 text-[0.92rem] text-ink focus:border-accent focus:bg-bg outline-none transition-all" />
              </div>
            </div>
            <div className="mb-4">
              <label className="block text-[0.64rem] uppercase tracking-[0.12em] text-ink-mid font-bold mb-2">Correo electrónico <span className="text-gold">*</span></label>
              <input type="email" required className="w-full bg-bg-alt border border-line rounded-xl px-4 py-3 text-[0.92rem] text-ink focus:border-accent focus:bg-bg outline-none transition-all" />
            </div>
            <div className="mb-4">
              <label className="block text-[0.64rem] uppercase tracking-[0.12em] text-ink-mid font-bold mb-2">Empresa</label>
              <input type="text" className="w-full bg-bg-alt border border-line rounded-xl px-4 py-3 text-[0.92rem] text-ink focus:border-accent focus:bg-bg outline-none transition-all" />
            </div>
            <div className="mb-4">
              <label className="block text-[0.64rem] uppercase tracking-[0.12em] text-ink-mid font-bold mb-2">Mensaje <span className="text-gold">*</span></label>
              <textarea required placeholder="Cuéntanos sobre tu operación y cómo podemos ayudarte..." className="w-full bg-bg-alt border border-line rounded-xl px-4 py-3 text-[0.92rem] text-ink focus:border-accent focus:bg-bg outline-none transition-all resize-y min-h-[110px]" />
            </div>
            <button type="submit" className="w-full bg-accent text-white py-4 rounded-full text-[0.88rem] font-medium flex justify-center items-center gap-2 active:bg-accent/90 active:scale-[0.98] transition-all mt-3">
              <span>Enviar mensaje</span>
              <ArrowRight size={16} />
            </button>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-ink text-white px-6 pt-12 pb-7">
        <div className="flex items-center gap-4 mb-3">
          <Image src="/logo.jpg" alt="RYSER" width={48} height={48} className="rounded-full brightness-200 invert" />
          <span className="font-serif text-[2.6rem] font-normal tracking-wide">RYSER</span>
        </div>
        <p className="text-[0.86rem] text-white/70 max-w-[30ch] mb-8 leading-relaxed">
          Reciclados y Servicios — Gestión integral de residuos industriales en Chihuahua, México.
        </p>
        <div className="h-px bg-white/18 mb-5" />
        <div className="flex justify-between text-[0.66rem] uppercase tracking-[0.12em] text-white/55 font-medium">
          <span>© 2026 RYSER</span>
          <span>Chihuahua, MX</span>
        </div>
      </footer>
    </div>
  )
}
