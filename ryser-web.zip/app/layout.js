import { Inter } from 'next/font/google'
import { Fraunces } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const fraunces = Fraunces({
  subsets: ['latin'],
  variable: '--font-fraunces',
  display: 'swap',
})

export const metadata = {
  title: 'RYSER — Gestión que Transforma',
  description: 'Reciclados y Servicios Industriales en Chihuahua, México. Venta de tarimas de madera, plásticos reciclados y servicios de gestión ambiental.',
  icons: { icon: '/logo.jpg' },
}

export default function RootLayout({ children }) {
  return (
    <html lang="es" className={`${inter.variable} ${fraunces.variable}`}>
      <head>
        <meta name="color-scheme" content="light only" />
      </head>
      <body className="font-sans bg-bg text-ink">
        {children}
      </body>
    </html>
  )
}
